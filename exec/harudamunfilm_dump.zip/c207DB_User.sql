-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c207.p.ssafy.io    Database: c207DB
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `userpid` int unsigned NOT NULL AUTO_INCREMENT,
  `roles` varchar(10) DEFAULT NULL,
  `userdesc` varchar(255) DEFAULT NULL,
  `userfcmtoken` varchar(255) DEFAULT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `userimg` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userpassword` varchar(255) DEFAULT NULL,
  `userpwa` varchar(255) DEFAULT NULL,
  `userpwq` int DEFAULT NULL,
  PRIMARY KEY (`userpid`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (49,'USER','항상 행복하세요~~ 모두~~','cQZmcO5ESYuPbL2V8DZMbj:APA91bE1VUSSESSvNQ56_R8k-CzHOKw_jnujZD3xrCyQOkczhsBOE2QJbnWGJe0b9Xi_Zfr-Ps25aps_uc-asYQyS8Z1-30-A-SrexPch3MPrkn1qaZ-_caa8tavMWXKGTfrR42u6jrV','test00','49_profileimagetemp5369748831068601507.jpg','테스트용','$2a$10$RvdVz.ISSZs7z5JavSn/Fe/DXNj6CKAMSmyTSNVjHepHoz9Lekdkm','아이유',3),(50,'USER','맛있겠당',NULL,'test01','50_profileimagetemp4929799953631711008.jpg','테스트01','$2a$10$PYcRjrRpa6AfyUCSUenTOe.MsB/oOuX8DRqgK4qozPTw51EBqLqru','아이유',3),(51,'USER','',NULL,'ksm001','baseimg.png','ksm001','$2a$10$z6ee8suVcJuwATqKPhn5K.57pzgIxmt.XeLlaMC0juPjO6s6f9Fhi','ksm001',1),(53,'USER','검색테스트','cIyZjXqjSiKtRafsoFaJPN:APA91bG5RKKi8yBllwuweuEZtQyb9618toghrIUJzZl8opqjm8_zBHGwi9ATQMDZhLkymYDIV6MCRcmIT-ub9IKJ2Rh_vXqEqxHL_wBt4rx7vicGBVyCyuZlSMAYYys5Qryo3BfGQi_i','dmdsns','53_profileimagetemp6719735844792381120.jpg','who1','$2a$10$qG0hhPU7zvJ2YJbySVC8zO01Vs7336slFry.xFchlCqg2VY5GMroq','ss',2),(54,'USER','','fiR-EU8DRy23s0HZIGJFvb:APA91bFy8m-LeXLClloPvBEm-ydcZtOl9fIFfOPk8mQukOcmh9bVZZ_2FA2qQKt4ccGF4OZhtcYUuUH1oBwS_ppapjW7vwc_fnWAtsUZTRgBm1u-XwULPI8L2fwIQUicD_IuwBqP5dQp','ssafykim','baseimg.png','싸피컨','$2a$10$m9D3wZcC8OwKfhUmJMvVwOUegoR6NCTCd/gn0DXYQKN624zuy/lmK','영빈',1),(55,'USER','','dewuFNx1TeGMOsIblFcIRv:APA91bEUITWVgUQr0l6KcY8QE6W66941zdMetR1LxrejVHRc29Qs47vqRsS4o5UQFTDOvms2ytPR-eUmiiiYmA6uU1Uu_fYIEuddAwG5loKfTbIccfSHGyO3wjneUcJle44qkW5A8Qk3','qqqqqq','baseimg.png','김규민','$2a$10$qcskvFMT/b.Uhb97mSr57.LlGHb.WjFd.SvoHdDXmXEtJezZMD1Fm','1',1),(56,'USER','',NULL,'wwwwww','baseimg.png','kgm2','$2a$10$Sw0tUEQODyoiENizSwyzXO43fo2Mf57Uir37nQ/FTkfLgiX.I9B.O','1',1),(57,'USER','',NULL,'ksm002','baseimg.png','ksm002','$2a$10$00LMfLmlCbc/3jKkRnzVwu7aRAQBNzc8lJOm/ajtp/Qbu4cjHGe2W','ksm002',1),(58,'USER','조코야 사랑해?','cFRSoQ6STL2bHSPiAIk_Cq:APA91bEBh0PhfXa1KO5yclfE2PVYg9auaeUtLn64wDJrFm5yiK4w9JyjCuyiYSs7Af-6vPDwnbQNsuEvMXcVpSfZ1dCDAX5GZSNfT_v0gFbEBI41f9QNGZ5OCoITpttTdlrXF_yZYXrt','1019ldh','58_profileimagetemp1365939166098011567.jpg','조코링','$2a$10$/DfVISD6hjrJAmc0e1lOx.Ufk4..KT3p81cYM8cpeWmFN9rgVm/p2','아이유',3),(59,'USER','복숭아가 곧 진리다',NULL,'ilovepeach','59_profileimagetemp6625429093956150765.jpg','복숭아좋아','$2a$10$jDnwfi4PyHRCpC1z2qaKB.ACPtFOK9OCBh7.VZpygCgcu/baSN936','아이유',3),(60,'USER','어제 필름 이어쓰기 테스트',NULL,'test02','60_profileimagetemp808828015372995894.jpg','어제필름테스트용','$2a$10$t.Ptox1DlLwIo.lHP5VzmuQOPhuA4y0zdl0dUlpw.wFxRtBotJ9my','아이유',3),(61,'USER','',NULL,'test03','baseimg.png','어제필름이어쓰기테스트용','$2a$10$z.RRGu9ZDukF7eqchvLaquSc9bePIWCMgaSyYvDZIcPzBBuYZCFLG','아이유',3),(62,'USER','굿바이','diM6hGr_QZOtwca_puiZdp:APA91bEVa9U-bcfcHf2nA0D9jUFjldc489QkrBO6G3S-Z-zCOaan8LKw3vk6qV6_-Q9YPYEK4TmZ08ln5kp5aQNIYqEEpohwPqInjV6QwKZ87XTZRc5c-DCtjh3EvyiU_Yj4pJGATaay','404err','62_profileimagetemp7606398597571160501.jpg','콜로소','$2a$10$Dbs/0Cl7VD3ayTxF3SAq0.qW3fJf7ART47QB6EVVue8fy0B6TedSy','나',1),(63,'USER','한줄소개입니다 한줄이맞나요',NULL,'ksm003','baseimg.png','이건 닉네임','$2a$10$BW43ZNxEImO3hm2cUvXkC.v0cDT.VefkX4rHOkKjWUbk.m95cFshe','ksm003',1),(64,'USER','',NULL,'ssafy7','baseimg.png','김싸피','$2a$10$4r1xGL/Y5R38o9XTzzetUeIlikFjMwT6.6D/aQ9E6XTljElkm34hC','이싸피',1),(65,'USER','',NULL,'ksm0818','baseimg.png','ksm0818','$2a$10$VwenTbz0vIB5NiahfI6OUeCaOjnpKg42d3qaSWFo1RaicrCx4qIRq','ksm0818',1),(66,'USER','? 깎는 개발자들',NULL,'todayfilm','66_profileimagetemp4225552838277384742.jpg','하루 담은 필름','$2a$10$/nEMrsZj7kLbHGAbx3EfIunBQguzCw4jwKuWdpmCyM0Wn4zkexqMi','아이유',3),(67,'USER','','dlMt1YjuTDi2c5QniQvD0i:APA91bGI7cW7NSf3GT1aZ5rJYGIWnypc5n0V3s8t5TrHCgVoA9MBhCt7Za6Gni_62qJ47PxYWKiGVL_Smm1vDx0pwJcXfntZ-FYHvrX2LiHh64WtKKo7UKGS9Ac3KOvrINnkQQEgn_z2','ksm0000','baseimg.png','ksm0000','$2a$10$EZunkwj96hGQpoiE4G4mdOpYRMQ4oujMiV8CYtXT7LucG9eyUMvN.','ksm0000',1);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  9:45:02
