-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7c207.p.ssafy.io    Database: c207DB
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Hash`
--

DROP TABLE IF EXISTS `Hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Hash` (
  `hashidx` int unsigned NOT NULL AUTO_INCREMENT,
  `hashname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hashidx`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Hash`
--

LOCK TABLES `Hash` WRITE;
/*!40000 ALTER TABLE `Hash` DISABLE KEYS */;
INSERT INTO `Hash` VALUES (51,'검색테스트용'),(52,'SSAFY'),(53,'프로젝트'),(54,'끝까지_열심히'),(55,'싸피'),(56,'유라'),(57,'수업중'),(58,'즐겁다'),(59,'행복하다'),(60,'하하하'),(61,''),(62,'우리집_막둥이'),(63,'깜찍한_조코_사랑해'),(64,'???'),(65,'오늘먹은_복숭아'),(66,'말랑말랑'),(67,'맛있다ㅎ'),(68,'해시태그'),(69,'새글알림'),(70,'테스트'),(71,'해시태그_길이_테스트용'),(72,'글자가_많아지면_밑으로_내려가려나'),(73,'아니면_나눠지려나'),(74,'즐겁다_싸피'),(75,'행복하다_공통_프로젝트'),(76,'하하하하하핳'),(77,'발표준비_밤샘각...'),(78,'블랙'),(79,'일상'),(80,'해히'),(81,'싸피!'),(82,'디자인_바꾸니까_이쁘다'),(83,'ㅎㅎ'),(84,'C207'),(85,'공통_프로젝트_드디어_끝'),(86,'신난다??'),(87,'다들_고생하셨습니다?'),(88,'s'),(89,'완성_후_이동_테스트'),(90,'발표_전날_오류나지마'),(91,'유스퀘어'),(92,'버스터미널에서_코딩하기'),(93,'즐겁다_하하하');
/*!40000 ALTER TABLE `Hash` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  9:45:03
